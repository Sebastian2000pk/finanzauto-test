import "./styles.css";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useFormik } from 'formik';
import * as yup from 'yup';

// Models
import { UserDetails } from "../../models/User";

// Components
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import Button from '@mui/material/Button';
import { userServices } from "../../services/userServices";

export const CreateUserPage = () => {
  const navigate = useNavigate();
  const { userId } = useParams();

  const [title, setTitle] = useState<string>("");
  const [gender, setGender] = useState<string>("");
  const [firstName, setFirstName] = useState<string>("");
  const [lastName, setLastName] = useState<string>("");
  const [picture, setPicture] = useState<string>('');
  const [email, setEmail] = useState<string>("");
  const [date, setDate] = useState<string>("");
  const [phone, setPhone] = useState<number>();

  const validationSchema = yup.object({
    title: yup
      .string()
      .required('El titulo es requerido'),
    email: yup
      .string()
      .email('Ingresa un email valido')
      .required('El correo es requerido'),
    lastName: yup
      .string()
      .required("El apellido es requerido"),
    firstName: yup
      .string()
      .required("El nombres es requerido"),
    picture: yup
      .string()
      .required("La foto es requerida"),
    gender: yup
      .string()
      .required("El genero es requerido"),
    dateOfBirth: yup
      .date()
      .required("La fecha de nacimiento es requerida"),
    phone: yup
      .number()
      .required("El numero de telefono es requerido"),
  });

  const formik = useFormik({
    initialValues: {
      title: "",
      email: "",
      lastName: "",
      firstName: "",
      picture: "",
      gender: "",
      dateOfBirth: "",
      phone: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      console.log(values)
      handleClickSave({
        email: values.email,
        title: values.title,
        lastName: values.lastName,
        firstName: values.firstName,
        picture: values.picture,
        gender: values.gender,
        dateOfBirth: new Date(values.dateOfBirth).toISOString(),
        phone: values.phone,
      });
    },
  })

  const handleClickCancel = () => {
    navigate("/");
  }

  const handleClickSave = async (data: UserDetails) => {
    const response = await userServices.createUser(data);
    if (!response) return;

    navigate("/");
  }

  const getUserById = async () => {
    if (userId) {
      const response = await userServices.getById(userId);
      
    }
  }

  useEffect(() => {
    getUserById();
  }, []);

  return (
    <div>

      <Paper className="form__container">

        <h3>Crear usuario</h3>

        {userId && <div>
          <TextField required id="firstName-input"
            label="ID"
            variant="outlined"
            disabled
            value={userId} />
        </div>}

        <FormControl fullWidth>

          <InputLabel id="title-select-label" required>Titulo</InputLabel>
          <Select
            labelId="title-select-label"
            id="title-select"
            value={formik.values.title}
            label="Titulo"
            name="title"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            error={formik.touched.title && Boolean(formik.errors.title)}
          >
            <MenuItem value="mr">Mr</MenuItem>
            <MenuItem value="ms">Ms</MenuItem>
            <MenuItem value="mrs">Mrs</MenuItem>
            <MenuItem value="miss">Miss</MenuItem>
            <MenuItem value="dr">Dr</MenuItem>
          </Select>
        </FormControl>

        <TextField required id="firstName-input"
          label="Nombres"
          variant="outlined"
          name="firstName"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.firstName && Boolean(formik.errors.firstName)} />

        <TextField required id="lastName-input"
          label="Apellidos"
          variant="outlined"
          name="lastName"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.lastName && Boolean(formik.errors.lastName)} />

        <TextField required id="picture-input"
          label="Foto"
          variant="outlined"
          name="picture"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.picture && Boolean(formik.errors.picture)} />

        <FormControl fullWidth>
          <InputLabel id="gender-select-label">Genero</InputLabel>
          <Select
            required
            labelId="gender-select-label"
            id="gender-select"
            value={formik.values.gender}
            label="Genero"
            name="gender"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            error={formik.touched.gender && Boolean(formik.errors.gender)}
          >
            <MenuItem value="male">Male</MenuItem>
            <MenuItem value="female">Female</MenuItem>
            <MenuItem value="other">Other</MenuItem>
          </Select>
        </FormControl>

        <TextField required id="email-input" label="Correo"
          value={formik.values.email}
          variant="outlined"
          type="email"
          name="email"
          error={formik.touched.email && Boolean(formik.errors.email)}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur} />

        <TextField id="date-input"
          label="Fecha nacimiento"
          variant="outlined"
          type="date"
          name="dateOfBirth"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.dateOfBirth && Boolean(formik.errors.dateOfBirth)} />

        <TextField
          id="phone-input"
          label="Telefono"
          variant="outlined"
          type="phone-number"
          name="phone"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.phone && Boolean(formik.errors.phone)} />

        <div className="buttons__container">
          <Button variant="outlined" onClick={handleClickCancel}>Cancelar</Button>
          <Button variant="contained" onClick={() => formik.handleSubmit()}>Guardar</Button>
        </div>
      </Paper>

    </div >
  )
};