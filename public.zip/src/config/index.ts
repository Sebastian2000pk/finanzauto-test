export const config = {
    BASE_API: "https://dummyapi.io/data/v1",
    token: "63473330c1927d386ca6a3a5",
}