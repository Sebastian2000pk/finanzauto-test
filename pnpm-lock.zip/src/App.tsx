import './App.css'
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";

// Pages
import { UserListPage } from './pages/userList'
import { CreateUserPage } from './pages/createUser'
import { UserDetailsPage } from './pages/userDetails';

const router = createBrowserRouter([
  {
    path: "/",
    element: <UserListPage />,
  },
  {
    path: "/create-user",
    element: <CreateUserPage />,
  },
  {
    path: "/user-details/:userId",
    element: <UserDetailsPage />,
  },
]);

function App() {

  return (
    <>
      <RouterProvider router={router} />
    </>
  )
}

export default App
